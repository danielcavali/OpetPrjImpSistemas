package com.example.OpetNetwork.Model;

public class Usuario {
    private int idUsuario;
    private String nomeUsuario;
    private String datadenascimento;
    private String Curso;
    private int periodo;
    private String emailUsuario;
    private String senhaUsuario;

    public int getIdUsuario() {
        return idUsuario;
    }
    public void setIdUsuario(int idUsuario) {
        this.idUsuario = idUsuario;
    }
    public String getNomeUsuario() {
        return nomeUsuario;
    }
    public void setNomeUsuario(String nomeUsuario) {
        this.nomeUsuario = nomeUsuario;
    }

    public String getDatadenascimento() {
        return datadenascimento;
    }

    public String getCurso() {
        return Curso;
    }

    public int getPeriodo() {
        return periodo;
    }

    public void setPeriodo(int periodo) {
        this.periodo = periodo;
    }

    public void setCurso(String curso) {
        Curso = curso;
    }

    public void setDatadenascimento(String datadenascimento) {
        this.datadenascimento = datadenascimento;
    }

    public String getEmailUsuario() {
        return emailUsuario;
    }
    public String Datadenascimento() {
        return datadenascimento;
    }
    public void setEmailUsuario(String emailUsuario) {
        this.emailUsuario = emailUsuario;
    }
    public String getSenhaUsuario() {
        return senhaUsuario;
    }
    public void setSenhaUsuario(String senhaUsuario) {
        this.senhaUsuario = senhaUsuario;
    }



}


