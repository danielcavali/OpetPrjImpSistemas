package com.example.OpetNetwork.Model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectionFactory {
    private String url = "url do banco aqui";
    private String user = "usuario do banco aqui";
    private String password = "senha do banco aqui";
    private Connection c = null;

    public Connection getConnection() {
        if (c == null) {
            try {
                Class.forName("url aqui");
                c = DriverManager.getConnection(url, user, password);
                System.out.println("Conectou com sucesso");
            } catch (SQLException e) {
                System.out.println("Erro ao conectar: " + e);
            } catch (ClassNotFoundException e) {
                System.out.println("Erro ao registrar: " + e);
            }
        }
        return c;
    }

    public void closeConnection() {
        if (c != null) {
            try {
                c.close();
                System.out.println("Fechou a conexao com sucesso");
            } catch (SQLException e) {
                System.out.println("Erro ao fechar conexao: " + e);
            }
        }
    }

}
