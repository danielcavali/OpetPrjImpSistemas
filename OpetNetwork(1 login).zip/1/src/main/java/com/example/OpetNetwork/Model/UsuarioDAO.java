package com.example.OpetNetwork.Model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
public class UsuarioDAO {
    private Connection c = null;

    public UsuarioDAO() {
        this.c = new ConnectionFactory().getConnection();
    }

    public void insere(Usuario u) {

        try {


            if (this.c == null) {
                this.c = new ConnectionFactory().getConnection();
            }


            String sql = "INSERT INTO Usuario" + " (idUsuario,nomeUsuario, Datadenascimento, curso,periodo, emailUsuario,senhaUsuario)"
                    + " values (?,?,?,?,?,?,?)";


            PreparedStatement ps = c.prepareStatement(sql);
            ps.setInt(1, u.getIdUsuario());
            ps.setString(3, u.getNomeUsuario());
            ps.setString(2,u.Datadenascimento());
            ps.setString(4, u.getCurso());
            ps.setInt(5,u.getPeriodo());
            ps.setString(6, u.getEmailUsuario());
            ps.setString(7, u.getSenhaUsuario());


            ps.execute();
        } catch (SQLException e) {
            System.out.println("Erro ao inserir Usuario: " + e);
        }
    }

    public Usuario consulta(Usuario u) {
        try {


            if (this.c == null) {
                this.c = new ConnectionFactory().getConnection();
            }


            String sql = "SELECT * FROM Usuario WHERE emailUsuario=? AND senhaUsuario=?";

            PreparedStatement ps = c.prepareStatement(sql);

            ps.setString(1, u.getEmailUsuario());
            ps.setString(2, u.getSenhaUsuario());


            ResultSet rs = ps.executeQuery();

            Usuario aux = null;

            while (rs.next()) {
                aux = new Usuario();
                aux.setIdUsuario(rs.getInt("IdUsuario"));
                aux.setNomeUsuario(rs.getString("NomeUsuario"));
                aux.setEmailUsuario(rs.getString("EmailUsuario"));
                aux.setSenhaUsuario(rs.getString("SenhaUsuario"));
            }


            return aux;

        } catch (SQLException e) {
            System.out.println("Erro ao consultar Usuario: " + e);
        }
        return null;
    }
    public void fechaConexao() {
        if (this.c != null) {
            // Fecha a conexão a cada operação
            try {
                this.c.close();
            } catch (SQLException e) {
                System.out.println("Erro ao fechar conexao: " + e);
            }
        }
    }
}
