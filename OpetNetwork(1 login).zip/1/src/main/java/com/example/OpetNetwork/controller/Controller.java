package com.example.OpetNetwork.controller;

import com.example.OpetNetwork.Model.Usuario;
import com.example.OpetNetwork.Model.UsuarioDAO;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;


public class Controller extends HttpServlet {
    private static final long serialVersionUID = 1L;


    public Controller() {
        super();
        // TODO Auto-generated constructor stub
    }


    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // TODO Auto-generated method stub
        // response.getWriter().append("Served at: ").append(request.getContextPath());

        // Criar um Bean para guardar os dados em memória
        Usuario u = new Usuario();

        // Criar um DAO para consultar no BD
        UsuarioDAO ud = new UsuarioDAO();

        // Carregar do fomulário para o Bean
        u.setEmailUsuario(request.getParameter("emailusuario"));
        u.setSenhaUsuario(request.getParameter("senhausuario"));

        // consultar o banco e se achar redirecionar para logado
        Usuario u2 = null;// criar outro bean para receber todos os dados se o usuario estiver no BD
        u2 = ud.consulta(u);// se o usuário estiver no BD carregará todos os dados para o objeto u2

        // Objeto para poder redirecionar
        RequestDispatcher rd;

        if (u2 != null) {// significa que validou o usuario (que ele está cadastrado no BD)

            // carregar os dados do usuario em um atributo para ser redirecionado
            request.setAttribute("usuario", u2);

            rd = request.getRequestDispatcher("/logado.jsp");
            rd.forward(request, response);

        } else {
            String m = "E-mail ou senha não encontrados";
            request.setAttribute("mensagem", m);

            rd = request.getRequestDispatcher("/index.jsp");
            rd.forward(request, response);
        }

    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // TODO Auto-generated method stub
        doGet(request, response);
    }

}
